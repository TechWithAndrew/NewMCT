## How to add models ##

- Simply go into the items folder under models, copy and paste a line of threshhold, change the number, add comma if needed, ending lines don't need commas

- To get your item /minecraft:give Player Item[custom_model_data={floats:[ModelNumber]}]
